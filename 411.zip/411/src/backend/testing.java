package backend;

import application.Main;

public class testing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TripStore userList = Main.getUserStore();
		userList.display();
	}

}

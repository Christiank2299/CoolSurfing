package backend;

import java.util.HashSet;

public class SpellCheck {

	HashSet<String> spellCheck;
	
	//.addAll
	// take a word and see if the hashset.contains() dont worry about capitlization toLowerCase().
	
}
